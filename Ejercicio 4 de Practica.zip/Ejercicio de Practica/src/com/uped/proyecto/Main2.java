package src.com.uped.proyecto;

import src.com.uped.proyecto.modelo.Vehiculo;

public class Main2 {

    public static void main(String[] args) {

        // Código de Vehiculo
        Vehiculo v1 = Vehiculo.nuevo("P123-789", "Kia");

        System.out.println(v1);

        v1.recorrer(150);

        System.out.println(v1);

        v1.recorrer(-20);
    }
}



